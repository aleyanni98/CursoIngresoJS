function mostrar()
{

var clave = prompt("ingrese clave.");
 
while (clave!="utn750"){
     
    clave = prompt("la clave es incorrecta,reingrese clave");
 
}
 
alert("la clave es correcta");

}//FIN DE LA FUNCIÓN
