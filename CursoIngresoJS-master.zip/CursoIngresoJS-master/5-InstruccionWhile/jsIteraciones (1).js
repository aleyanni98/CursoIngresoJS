function mostrar()
{
	var i = 1;
	while ( i < 11){
	alert(i);
	i++;

	}
}//FIN DE LA FUNCIÓN