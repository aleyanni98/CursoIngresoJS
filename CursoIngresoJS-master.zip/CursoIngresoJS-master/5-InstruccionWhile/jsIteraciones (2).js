function mostrar()
{
	var i = 10;
	while ( i > 0 ){
	alert(i);
	i--;

	}


}//FIN DE LA FUNCIÓN