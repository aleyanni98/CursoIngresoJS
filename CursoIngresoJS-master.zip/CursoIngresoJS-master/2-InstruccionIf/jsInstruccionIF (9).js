function mostrar()
{
	//Genero el número RANDOM entre 1 y 10 
	var numero;
	numero=Math.floor(Math.random()*(11)+1);
	alert(numero);

}//FIN DE LA FUNCIÓN