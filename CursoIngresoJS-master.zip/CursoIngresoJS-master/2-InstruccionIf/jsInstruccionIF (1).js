function mostrar()
{
//tomo la edad  
var edad= document.getElementById("edad").value;
if(edad==15);{
alert("Niña bonita");

}

}//FIN DE LA FUNCIÓN