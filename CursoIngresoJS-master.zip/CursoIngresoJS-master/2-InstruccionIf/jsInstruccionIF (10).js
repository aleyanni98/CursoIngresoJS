function mostrar()
{
	//Genero el número RANDOM entre 1 y 10 
	 var mensaje;
	 var nota;
	 numero=Math.floor(Math.random()*(11)+1);
	 if(nota >=9){
		 alert("Exelente");
	 }
	 else if(nota>=3

}//FIN DE LA FUNCIÓN